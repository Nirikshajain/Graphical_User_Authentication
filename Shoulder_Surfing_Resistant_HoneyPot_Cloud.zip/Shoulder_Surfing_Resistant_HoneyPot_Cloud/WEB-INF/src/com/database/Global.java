package com.database;

public class Global
{

    public final static String Driver="com.mysql.jdbc.Driver";
	public final static String URL= "jdbc:mysql://localhost:3306/db_shoulder_surfing";
	
	
	public final static String Uname="root";
	public final static String Pass="root";
	
	
	
	
	
	
}
