package com.Symmetric.cryptography_AES;

public class Main
{
	public static void main(String[] args) throws Exception
	{
		
		AES_File_EncNdecForFile.encryptFile("D:/AES/shanu_rabbit.jpg","D:/AES/ENCnewTest.jpg","0x1d7gv7wtsc9ny8");
		AES_File_EncNdecForFile.decryptFile("D:/AES/ENCnewTest.jpg","D:/AES/DCRnewTest.jpg","0x1d7gv7wtsc9ny8");
	}
}
