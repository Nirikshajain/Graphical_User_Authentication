package com.user;

import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Map;
import java.util.Random;

import javax.imageio.ImageIO;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.DAOFactory.User;
import com.Symmetric.cryptography_AES.AES_File_EncNdecForFile;
import com.util.Send_SMS_Service;
import com.util.Utility;



/**
 * @author Amutha
 * @ProjectName Web_GraphicalPassword
 * @FileName NewUser.java
 */
public class DownloadFile extends HttpServlet
{
	RequestDispatcher rd = null;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp)	throws ServletException, IOException 
	{
		

		try
		{
			String submit=req.getParameter("submit");
			
			
				HttpSession hs=req.getSession();	
				
				
				
				    String uid=hs.getAttribute("uid").toString();
				    
				    if(submit.equals("get"))
				    {
				    	    String fileid=req.getParameter("fileid");
				    	    hs.setAttribute("fileid",fileid);
				    	    hs.setAttribute("counter",1);
							RequestDispatcher rd=req.getRequestDispatcher("/jsp/User/passkeyupload.jsp");
							rd.forward(req, resp);
				    }
				    
				    if(submit.equals("submitpasskey"))
				    {
				    	String passkey=req.getParameter("passkey");
				    	
				    				    	
				    	String fileid=hs.getAttribute("fileid").toString();
				    	
				    	String filepasskey=User.getuserfilepasskey(fileid);
				    	
				    	String filename=User.getuserfilename(fileid);
				    	if(passkey.equals(filepasskey))
				    	{
				    		//String root1=getServletContext().getRealPath("/File_Trans/Enc_upload/");
				    		
				    		String root1=getServletContext().getRealPath("/File_Trans/Enc_Download/");
				    		String root2=getServletContext().getRealPath("/File_Trans/Dec_Download/");
				    		boolean result=false;
				    		result=Utility.download(Utility.getPro("server"), Utility.getPro("user"), Utility.getPro("pass"),filename,root1);
							
				    		AES_File_EncNdecForFile.decryptFile(root1 +"/"+filename,root2 +"/"+filename,"0x1d7gv7wtsc9ny8");
				    		try
				    		{
				    		
				    		String downloadedfilepath=root2+"/"+filename;
				    		File file = new File(downloadedfilepath);
				    		ServletContext context = getServletContext();
				    		String mimeType = context.getMimeType(downloadedfilepath);
				    		if (mimeType == null) 
				    		{
				    		// set to binary type if MIME mapping not found
				    		mimeType = "application/octet-stream";
				    		}
				    		System.out.println("MIME type: " + mimeType);
				    														
				    		// modifies response
				    		resp.setContentType(mimeType);
				    		resp.setContentLength((int) file.length());

				    		System.out.println("=======lenghthhhhh========="+(int) file.length());
				    		FileInputStream inStream = new FileInputStream(file);												
				    		// forces download
				    		String headerKey = "Content-Disposition";
				    		String headerValue = String.format("attachment; filename=\"%s\"", file.getName());
				    		
				    		resp.setHeader(headerKey, headerValue);
				    		// obtains response's output stream
				    		OutputStream outStream = resp.getOutputStream();
				    														
				    		byte[] buffer = new byte[100096];
				    		int bytesRead1 = -1;
				    														
				    		while ((bytesRead1 = inStream.read(buffer)) != -1) 
				    		{
				    		outStream.write(buffer, 0, bytesRead1);
				    		}
				    		inStream.close();
				    		outStream.close();
				    		}
				    		catch(Exception e)
				    		{
				    			e.printStackTrace();
				    		}
				    	}
				    	
				    	else
				    	{
				    		
				    		String root2=getServletContext().getRealPath("/File_Trans/DummyFiles/");
				    		
				    		int counter=Integer.parseInt(hs.getAttribute("counter").toString());
				    		counter++;
				    		System.out.println("=====counter==="+counter);
				    		if(counter>3)
				    		{
				    			
				    			String ip=hs.getAttribute("ip").toString();
				    			
				    			User.inserttoattackerIP(uid,ip);
				    			
				    			
				    			FileInputStream instream = null;
				    			FileOutputStream outstream = null;
				    		 
				    		    	try{
				    		    	    File infile =new File(root2+"/"+"dummyfile1.txt");
				    		    	    File outfile =new File(root2+"/"+filename);
				    		    	    if(!outfile.exists())
				    		    	    {
				    		    	    	outfile.createNewFile();
				    		    	    }
				    		 
				    		    	    instream = new FileInputStream(infile);
				    		    	    outstream = new FileOutputStream(outfile);
				    		 
				    		    	    byte[] buffer = new byte[1024];
				    		 
				    		    	    int length;
				    		    	    /*copying the contents from input stream to
				    		    	     * output stream using read and write methods
				    		    	     */
				    		    	    while ((length = instream.read(buffer)) > 0){
				    		    	    	outstream.write(buffer, 0, length);
				    		    	    }

				    		    	    //Closing the input/output file streams
				    		    	    instream.close();
				    		    	    outstream.close();
				    		    	}
				    		    	catch (Exception e)
				    		    	{
										// TODO: handle exception
									}
				    			
				    			
				    			//===========================================
				    			     counter=1;
				    		    	 hs.setAttribute("counter",counter);
				    			 
				    			 
				    			
				    			try
					    		{
				    			
				    				
					    		
					    		String downloadedfilepath=root2+"/"+filename;
					    		File file = new File(downloadedfilepath);
					    		ServletContext context = getServletContext();
					    		String mimeType = context.getMimeType(downloadedfilepath);
					    		if (mimeType == null) 
					    		{
					    		// set to binary type if MIME mapping not found
					    		mimeType = "application/octet-stream";
					    		}
					    		System.out.println("MIME type: " + mimeType);
					    														
					    		// modifies response
					    		resp.setContentType(mimeType);
					    		resp.setContentLength((int) file.length());

					    		System.out.println("=======lenghthhhhh========="+(int) file.length());
					    		FileInputStream inStream = new FileInputStream(file);												
					    		// forces download
					    		String headerKey = "Content-Disposition";
					    		String headerValue = String.format("attachment; filename=\"%s\"", file.getName());
					    		
					    		resp.setHeader(headerKey, headerValue);
					    		// obtains response's output stream
					    		OutputStream outStream = resp.getOutputStream();
					    														
					    		byte[] buffer = new byte[100096];
					    		int bytesRead1 = -1;
					    														
					    		while ((bytesRead1 = inStream.read(buffer)) != -1) 
					    		{
					    		outStream.write(buffer, 0, bytesRead1);
					    		}
					    		inStream.close();
					    		outStream.close();
					    		}
					    		catch(Exception e)
					    		{
					    			e.printStackTrace();
					    		}
				    		}
				    		else
				    		{
				    			 hs.setAttribute("counter",counter);
				    			 RequestDispatcher rd=req.getRequestDispatcher("/jsp/User/passkeyupload.jsp?no=1");
									rd.forward(req, resp);
				    			 
				    		}
				    		
					    	
					    	
					    	
					    	
				    	}
				    	
				    	
				     
				     
				   
				    }
			
			
		}	
		catch (Exception e)
		{
			System.out.println("********* Exception In New User Servlet ********\n");
			e.printStackTrace();
		}

	}

}
