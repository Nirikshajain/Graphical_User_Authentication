/**
 * 
 */
package com.user;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.SecureRandom;
import java.sql.ResultSet;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.DAOFactory.User;
import com.Symmetric.cryptography_AES.AES_File_EncNdecForFile;
import com.util.Send_Mail_Attachment;
import com.util.Utility;

public class UploadToServer extends HttpServlet

{
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws IOException
			
			{
		
		HttpSession session=request.getSession();
		PrintWriter out = response.getWriter();
		try
		
		{
			String fileName = "", root = "", md = "", root1 = "",root2="" ,dir = "shoulder_surfing";  
			String status; 
			String[] name = new String[2];
			int i = 0;
			File uploadedFile = null;
			File uploadedFile1=null;
			ResultSet rs = null;
			boolean flag = false;
			boolean flag_upload = false;
			RequestDispatcher rd = null;
			Random random = new Random();
			int num, num1 = 0;
			boolean isMultipart = ServletFileUpload.isMultipartContent(request);
			
		
			if (isMultipart)
			{
				FileItemFactory factory = new DiskFileItemFactory();
				ServletFileUpload upload = new ServletFileUpload(factory);
				try 
				{
					List items = upload.parseRequest(request);
					Iterator iterator = items.iterator();
					
					while (iterator.hasNext())
					{
						FileItem item = (FileItem) iterator.next();
						if (item.isFormField())
						{
							name[i] = item.getString();
							i++;
						} 
						else 
						{
							fileName = item.getName();
							System.out.println("filename iss" + fileName);
							root = getServletContext().getRealPath("/File_Trans/Upload/");
							
							uploadedFile = new File(root +"/"+fileName);
							
							System.out.println("Directory name iss" + uploadedFile);
							item.write(uploadedFile);
						}
					}
					
					root1=getServletContext().getRealPath("/File_Trans/Enc_upload/");
					AES_File_EncNdecForFile.encryptFile(root +"/"+fileName,root1 +"/"+fileName,"0x1d7gv7wtsc9ny8");
					uploadedFile1=new File(root1 +"/"+fileName);
					//=======upload to file======
					 flag_upload=Utility.uploadFile(Utility.getPro("server"), Utility.getPro("user"), Utility.getPro("pass"),fileName,uploadedFile1, dir); 
					//=======upload to file======
					
					
					HttpSession hs=request.getSession();	
					String uid=hs.getAttribute("uid").toString();
					String filepasskey= UploadToServer.randomString(8);
					
					boolean result=User.inserttofile(fileName, uid,  filepasskey);
					String usermail=User.getMailid(uid);
					String userphone=User.getUserPhone(uid);
					String message="Pass Key of the file\n"+fileName+"\n"+filepasskey+"\n";
					Send_Mail_Attachment.sendPersonalizedMail(usermail, "Pass Key of the file ", message, "no");
					
					if(result)
					{
					
					  rd=request.getRequestDispatcher("/jsp/User/uploadfile.jsp?no=1");
						rd.forward(request, response);
					}
					else
					{
						 rd=request.getRequestDispatcher("/jsp/User/uploadfile.jsp?no=2");
							rd.forward(request, response);
					}
				}
					
					
			
                  catch (Exception e1)
                  {
                	  rd=request.getRequestDispatcher("/jsp/User/uploadfile.jsp?no=2");
						rd.forward(request, response);
					System.out.println("Opps's Error is in User UploadToCloud isMultipart Servlet......"+ e1);
					out.println("Opps's Error is in User UploadToCloud Servlet isMultipart......"+ e1);
				}
			}
		} 
		catch (Exception e)
		{
			System.out.println("Opps's Error is in User UploadToCloud Servlet......"+ e);
			out.println("Opps's Error is in User UploadToCloud Servlet......"+ e);
		}
	}
	
	
	static final String AB = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
	static SecureRandom rnd = new SecureRandom();

	public static String randomString( int len )
	{
	   StringBuilder sb = new StringBuilder( len );
	   for( int i = 0; i < len; i++ ) 
	      sb.append( AB.charAt( rnd.nextInt(AB.length()) ) );
	   return sb.toString();
	}
}
