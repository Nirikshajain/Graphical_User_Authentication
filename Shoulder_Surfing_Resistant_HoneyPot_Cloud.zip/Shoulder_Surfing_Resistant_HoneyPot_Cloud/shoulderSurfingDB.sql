/*
SQLyog - Free MySQL GUI v5.19
Host - 5.5.17 : Database - db_shoulder_surfing
*********************************************************************
Server version : 5.5.17
*/

SET NAMES utf8;

SET SQL_MODE='';

create database if not exists `db_shoulder_surfing`;

USE `db_shoulder_surfing`;

SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO';

/*Table structure for table `m_admin` */

DROP TABLE IF EXISTS `m_admin`;

CREATE TABLE `m_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adminid` varchar(50) DEFAULT NULL,
  `adminname` varchar(50) DEFAULT NULL,
  `adminpass` varchar(50) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `city` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `m_admin` */

insert into `m_admin` (`id`,`adminid`,`adminname`,`adminpass`,`gender`,`email`,`phone`,`city`) values (1,'admin','admin','111','male','manohar7789@gmail.com','9916119479','Bengaluru');

/*Table structure for table `m_attackers_ip` */

DROP TABLE IF EXISTS `m_attackers_ip`;

CREATE TABLE `m_attackers_ip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hacked_userid` varchar(50) DEFAULT NULL,
  `ip_address` varchar(50) DEFAULT NULL,
  `status` varchar(30) DEFAULT 'active',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

/*Data for the table `m_attackers_ip` */

insert into `m_attackers_ip` (`id`,`hacked_userid`,`ip_address`,`status`) values (1,'manu','192.168.0.104','blocked');
insert into `m_attackers_ip` (`id`,`hacked_userid`,`ip_address`,`status`) values (2,'manu','192.168.0.108','blocked');
insert into `m_attackers_ip` (`id`,`hacked_userid`,`ip_address`,`status`) values (3,'manu','192.168.0.105','active');

/*Table structure for table `m_file` */

DROP TABLE IF EXISTS `m_file`;

CREATE TABLE `m_file` (
  `file_id` int(11) NOT NULL AUTO_INCREMENT,
  `file_name` varchar(50) DEFAULT NULL,
  `file_owner` varchar(50) DEFAULT NULL,
  `file_pass_key` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

/*Data for the table `m_file` */

insert into `m_file` (`file_id`,`file_name`,`file_owner`,`file_pass_key`) values (1,'sample1test.txt','manu','3iPluZ7v');
insert into `m_file` (`file_id`,`file_name`,`file_owner`,`file_pass_key`) values (2,'sample2test.txt','manu','FF7pAr8Y');
insert into `m_file` (`file_id`,`file_name`,`file_owner`,`file_pass_key`) values (3,'sample1test.txt','manu','OSqs1fPj');
insert into `m_file` (`file_id`,`file_name`,`file_owner`,`file_pass_key`) values (4,'sample1test.txt','manu','L7zMIhjt');
insert into `m_file` (`file_id`,`file_name`,`file_owner`,`file_pass_key`) values (5,'samp.txt','manu','4AOCPkDQ');
insert into `m_file` (`file_id`,`file_name`,`file_owner`,`file_pass_key`) values (6,'saaa.txt','manu','wgJVaokh');
insert into `m_file` (`file_id`,`file_name`,`file_owner`,`file_pass_key`) values (7,'saaa.txt','manu','ei5zTYIF');
insert into `m_file` (`file_id`,`file_name`,`file_owner`,`file_pass_key`) values (8,'saaa.txt','manu','pTCbdITu');
insert into `m_file` (`file_id`,`file_name`,`file_owner`,`file_pass_key`) values (9,'testingfile.txt','manu','kwK9cOgh');
insert into `m_file` (`file_id`,`file_name`,`file_owner`,`file_pass_key`) values (10,'register.jpg','manu','YVgfoFK6');
insert into `m_file` (`file_id`,`file_name`,`file_owner`,`file_pass_key`) values (11,'tomcat plugins.txt','manu','gquI9Og4');

/*Table structure for table `m_user` */

DROP TABLE IF EXISTS `m_user`;

CREATE TABLE `m_user` (
  `u_no` int(10) NOT NULL AUTO_INCREMENT,
  `u_id` varchar(100) DEFAULT NULL,
  `u_txtpwd` varchar(100) DEFAULT NULL,
  `u_name` varchar(50) DEFAULT NULL,
  `u_gender` varchar(10) DEFAULT NULL,
  `u_email` varchar(100) DEFAULT NULL,
  `u_phone` varchar(20) DEFAULT NULL,
  `u_city` varchar(50) DEFAULT NULL,
  `random_image1` varchar(100) DEFAULT NULL,
  `random_image2` varchar(100) DEFAULT NULL,
  `random_image3` varchar(100) DEFAULT NULL,
  `selectedlocation1` varchar(100) DEFAULT NULL,
  `selectedlocation2` varchar(100) DEFAULT NULL,
  `selectedlocation3` varchar(100) DEFAULT NULL,
  `hash_key` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`u_no`),
  KEY `FK_m_user` (`u_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

/*Data for the table `m_user` */

insert into `m_user` (`u_no`,`u_id`,`u_txtpwd`,`u_name`,`u_gender`,`u_email`,`u_phone`,`u_city`,`random_image1`,`random_image2`,`random_image3`,`selectedlocation1`,`selectedlocation2`,`selectedlocation3`,`hash_key`) values (1,'manu','123','manu','male','manohar@celestialv.com','9988998899','banglore','Image3','Image1','Image2','3,4','3,4','3,4','7a4debac518cbec447e15b7691aca97e');

/*Table structure for table `m_user_otp` */

DROP TABLE IF EXISTS `m_user_otp`;

CREATE TABLE `m_user_otp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uid` varchar(50) DEFAULT NULL,
  `image1` varchar(50) DEFAULT NULL,
  `image2` varchar(50) DEFAULT NULL,
  `image3` varchar(50) DEFAULT NULL,
  `randomrow1` int(11) DEFAULT NULL,
  `randomcol1` int(11) DEFAULT NULL,
  `randomrow2` int(11) DEFAULT NULL,
  `randomcol2` int(11) DEFAULT NULL,
  `randomrow3` int(11) DEFAULT NULL,
  `randomcol3` int(11) DEFAULT NULL,
  `horizantal_image` int(11) DEFAULT NULL,
  `vertical_image` int(11) DEFAULT NULL,
  `m_locations` varchar(50) DEFAULT NULL,
  `hash_key` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

/*Data for the table `m_user_otp` */

SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
