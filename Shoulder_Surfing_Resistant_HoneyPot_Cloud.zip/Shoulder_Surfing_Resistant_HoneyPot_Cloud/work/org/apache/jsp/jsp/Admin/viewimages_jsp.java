package org.apache.jsp.jsp.Admin;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import com.util.*;
import java.sql.*;

public final class viewimages_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static final JspFactory _jspxFactory = JspFactory.getDefaultFactory();

  private static java.util.List _jspx_dependants;

  private javax.el.ExpressionFactory _el_expressionfactory;
  private org.apache.AnnotationProcessor _jsp_annotationprocessor;

  public Object getDependants() {
    return _jspx_dependants;
  }

  public void _jspInit() {
    _el_expressionfactory = _jspxFactory.getJspApplicationContext(getServletConfig().getServletContext()).getExpressionFactory();
    _jsp_annotationprocessor = (org.apache.AnnotationProcessor) getServletConfig().getServletContext().getAttribute(org.apache.AnnotationProcessor.class.getName());
  }

  public void _jspDestroy() {
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      response.setContentType("text/html; charset=ISO-8859-1");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write("<!DOCTYPE html>\r\n");
      out.write("<!--[if IE 8 ]><html class=\"ie ie8\" class=\"no-js\" lang=\"en\"> <![endif]-->\r\n");
      out.write("<!--[if (gte IE 9)|!(IE)]><!--><html class=\"no-js\" lang=\"en\"> <!--<![endif]-->\r\n");
      out.write("  \r\n");
      out.write("   \r\n");
      out.write("    \r\n");
      out.write("\r\n");
      out.write("<head>\r\n");
      out.write("    <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\r\n");
      out.write("    <meta http-equiv=\"X-UA-Compatible\" content=\"IE=edge\">\r\n");
      out.write("    <title>Animation - Electrify Responsive Multipurpose Template</title>\r\n");
      out.write("    <meta name=\"description\" content=\"\">\r\n");
      out.write("    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1, maximum-scale=1\" />\r\n");
      out.write("\r\n");
      out.write("    <!-- CSS FILES -->\r\n");
      out.write("    <link rel=\"stylesheet\" href=\"css/bootstrap.min.css\"/>\r\n");
      out.write("    <link rel=\"stylesheet\" href=\"css/style.css\">\r\n");
      out.write("    <link rel=\"stylesheet\" type=\"text/css\" href=\"css/style.css\" media=\"screen\" data-name=\"skins\">\r\n");
      out.write("    <link rel=\"stylesheet\" href=\"css/layout/wide.css\" data-name=\"layout\">\r\n");
      out.write("    <link rel=\"stylesheet\" href=\"css/animate.css\" type=\"text/css\"/>\r\n");
      out.write("\r\n");
      out.write("    <link rel=\"stylesheet\" type=\"text/css\" href=\"css/switcher.css\" media=\"screen\" />\r\n");
      out.write("    \r\n");
      out.write("    <!--  <link rel=\"stylesheet\" href=\"tablecss/tabcss/style.css\"> -->\r\n");
      out.write("     <link rel=\"stylesheet\" href=\"css/pagenationcss.css\" rel=\"stylesheet\">\r\n");
      out.write("<script src=\"");
      out.print(request.getContextPath() );
      out.write("/js/pagenation.js\"></script>\r\n");
      out.write("    \r\n");
      out.write("    <link rel=\"stylesheet\" type=\"text/css\" href=\"Style/css/vendor/bootstrap.min.css\">\r\n");
      out.write("\t<link rel=\"stylesheet\" type=\"text/css\" href=\"Style/css/style.css\">\r\n");
      out.write("    <link rel=\"stylesheet\" type=\"text/css\" href=\"Style/css/style.css\" media=\"screen\" data-name=\"skins\">\r\n");
      out.write("    <link rel=\"stylesheet\" href=\"Style/css/style-fraction.css\" type=\"text/css\" charset=\"utf-8\" />\r\n");
      out.write("    <link rel=\"stylesheet\" href=\"Style/css/fractionslider.css\">\r\n");
      out.write("\r\n");
      out.write("    <link rel=\"stylesheet\" type=\"text/css\" href=\"Style/css/switcher.css\" media=\"screen\" />\r\n");
      out.write("    <link rel=\"stylesheet\" href=\"HomepageCss/css/styles.css\" type=\"text/css\" />\r\n");
      out.write("    <style>\r\n");
      out.write("    td{\r\n");
      out.write("        cursor:pointer;\r\n");
      out.write("        background: -moz-linear-gradient(top, #ffffff, #D1E3E9);\r\n");
      out.write("        background: -webkit-gradient(linear, 0% 0%, 0% 100%, from(#ffffff), to(#D1E3E9));\r\n");
      out.write("        text-align:center;\r\n");
      out.write("        width: 50px;\r\n");
      out.write("        height: 50px;\r\n");
      out.write("    }\r\n");
      out.write("    \r\n");
      out.write("    td img {\r\n");
      out.write("    max-width:100%;\r\n");
      out.write("    height:auto;\r\n");
      out.write("}\r\n");
      out.write(" \r\n");
      out.write("    td:hover{\r\n");
      out.write("        background: -moz-linear-gradient(top, #249ee4, #057cc0);\r\n");
      out.write("        background: -webkit-gradient(linear, 0% 0%, 0% 100%, from(#249ee4), to(#057cc0));\r\n");
      out.write("    }\r\n");
      out.write(" \r\n");
      out.write("    td:active\r\n");
      out.write("    {\r\n");
      out.write("        background: -moz-linear-gradient(top, #057cc0, #249ee4);\r\n");
      out.write("        background: -webkit-gradient(linear, 0% 0%, 0% 100%, from(#057cc0), to(#249ee4));\r\n");
      out.write("    }\r\n");
      out.write(" \r\n");
      out.write("    #result{\r\n");
      out.write("        font-weight:bold;\r\n");
      out.write("        font-size:16pt;\r\n");
      out.write("    }\r\n");
      out.write("    \r\n");
      out.write("    #myTable{\r\n");
      out.write("        width:100%; height:auto;\r\n");
      out.write("\r\n");
      out.write("}\r\n");
      out.write("\r\n");
      out.write("img {\r\n");
      out.write("  width: 100%;\r\n");
      out.write("  display: block;\r\n");
      out.write("}\r\n");
      out.write("\r\n");
      out.write("    \r\n");
      out.write("</style>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<script  src=\"http://code.jquery.com/jquery-1.9.1.min.js\" ></script>     \r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("<script class=\"jsbin\"\r\n");
      out.write("\tsrc=\"http://ajax.googleapis.com/ajax/libs/jquery/1.4.0/jquery.min.js\"></script>\r\n");
      out.write("\r\n");
      out.write("    \r\n");
      out.write("    ");

	
	ResultSet rs=(ResultSet)request.getAttribute("rs");
	int no=Utility.parse(request.getParameter("no"));
	int id=0;
	String u_no="",u_id="",u_txtpwd="",u_name="",u_gender="",u_email="",u_phone="",u_city="",random_image1="",random_image2="",random_image3="",selectedlocation1="",selectedlocation2="",selectedlocation3="",hash_key="";
	if(no==0)
	/* while(rs.next())
	{
		
		userid=rs.getString(2);
		name=rs.getString(3);
		gender=rs.getString(5);
		email=rs.getString(6);
		phone=rs.getString(7);
		city=rs.getString(8);
	} */

      out.write("\r\n");
      out.write("\r\n");

String uid=session.getAttribute("adminid").toString(); 

      out.write("\r\n");
      out.write("</head>\r\n");
      out.write("<body>\r\n");
String image="Image1";
System.out.println("------randimg1---"+image);

      out.write("\r\n");
      out.write("\r\n");
      out.write("<!--Start Header-->\r\n");
      out.write("<header id=\"header\">\r\n");
      out.write("        <div id=\"top-bar\">\r\n");
      out.write("            <div class=\"container\">\r\n");
      out.write("                <div class=\"row\">\r\n");
      out.write("                    <div class=\"col-sm-8 top-info hidden-xs\">\r\n");
      out.write("                        <span><i class=\"fa fa-phone\"></i></span>\r\n");
      out.write("                        <span><i class=\"fa fa-envelope\"></i></span>\r\n");
      out.write("                    </div>\r\n");
      out.write("                   \r\n");
      out.write("                </div>\r\n");
      out.write("            </div>\r\n");
      out.write("        </div>\r\n");
      out.write("        \r\n");
      out.write("        \r\n");
      out.write("        \r\n");
      out.write("        <div id=\"logo-bar\">\r\n");
      out.write("            <div class=\"container\">\r\n");
      out.write("                <div class=\"row\">\r\n");
      out.write("                  \r\n");
      out.write("                    <div  class=\"col-lg-3 col-sm-3 \" style=\"position:absolute;width: 100%; top: 5px;height:100px;\">\r\n");
      out.write("                        <div id=\"logo\">\r\n");
      out.write("                            <h1><a href=\"\"><img alt=\"logo\" style=\"width: 100%;height:100px;\" src=\"images/1.png\"/></a></h1>\r\n");
      out.write("                        </div>\r\n");
      out.write("                    </div>\r\n");
      out.write("                    </div>\r\n");
      out.write("                    </div>\r\n");
      out.write("                    </div>\r\n");
      out.write("                     <div id=\"top-bar\" style=\"position:absolute; top: 150px; width:100%;\"  >\r\n");
      out.write("            <div class=\"container\">\r\n");
      out.write("                <div class=\"row\">\r\n");
      out.write("                    <div class=\"col-sm-8 top-info hidden-xs\" >\r\n");
      out.write("                        \r\n");
      out.write("                    </div>\r\n");
      out.write("                   \r\n");
      out.write("                </div>\r\n");
      out.write("            </div>\r\n");
      out.write("        </div>\r\n");
      out.write("        \r\n");
      out.write("        \r\n");
      out.write("        \r\n");
      out.write("        \r\n");
      out.write("        \r\n");
      out.write("        \r\n");
      out.write("        <div id=\"logo-bar\">\r\n");
      out.write("            <div class=\"container\">\r\n");
      out.write("                <div class=\"row\">\r\n");
      out.write("                   \r\n");
      out.write("                    <div  class=\"col-lg-3 col-sm-3 \">\r\n");
      out.write("                        <div id=\"logo\">\r\n");
      out.write("                           \r\n");
      out.write("                        </div>\r\n");
      out.write("                    </div>\r\n");
      out.write("                    <!-- Navigation\r\n");
      out.write("    ================================================== -->\r\n");
      out.write("                    <div class=\"col-lg-9 col-sm-9\" style=\"position:absolute; top: 150px;\">\r\n");
      out.write("                        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">\r\n");
      out.write("                            <!--  <div class=\"container\">-->\r\n");
      out.write("                            <div class=\"navbar-header\">\r\n");
      out.write("                                <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">\r\n");
      out.write("                                    <span class=\"sr-only\">Toggle navigation</span>\r\n");
      out.write("                                    <span class=\"icon-bar\"></span>\r\n");
      out.write("                                    <span class=\"icon-bar\"></span>\r\n");
      out.write("                                    <span class=\"icon-bar\"></span>\r\n");
      out.write("                                </button>\r\n");
      out.write("                            </div>\r\n");
      out.write("                            <div class=\"navbar-collapse collapse\">\r\n");
      out.write("                                <ul class=\"nav navbar-nav\">\r\n");
      out.write("                                    <li><a href=\"");
      out.print(request.getContextPath() );
      out.write("/AdminHome?submit=get\">Home</a>\r\n");
      out.write("                                      \r\n");
      out.write("                                    </li>\r\n");
      out.write("\r\n");
      out.write("                                    <li><a href=\"#\">Show Profile</a>\r\n");
      out.write("                                        <ul class=\"dropdown-menu\">\r\n");
      out.write("                                            <li><a href=\"");
      out.print(request.getContextPath() );
      out.write("/AdminProfile\">View Profile</a></li>\r\n");
      out.write("                                            <li><a href=\"");
      out.print(request.getContextPath() );
      out.write("/EditAdminProfile?submit=edit\">Edit Profile</a></li>\r\n");
      out.write("                                           \r\n");
      out.write("                                        </ul>\r\n");
      out.write("                                    </li>\r\n");
      out.write("                                      <li> <a href=\"");
      out.print(request.getContextPath() );
      out.write("/ViewUsers?submit=view\">View Users</a>\r\n");
      out.write("                                       \r\n");
      out.write("                                    </li>\r\n");
      out.write("                                      <li> <a href=\"");
      out.print(request.getContextPath() );
      out.write("/ViewUsers?submit=viewfakeip\">View Fake IP Address</a>\r\n");
      out.write("                                       \r\n");
      out.write("                                    </li>\r\n");
      out.write("                                    <li> <a href=\"");
      out.print(request.getContextPath() );
      out.write("/ViewImages?submit=view\">View Password Images</a>\r\n");
      out.write("                                       \r\n");
      out.write("                                    </li>\r\n");
      out.write("\r\n");
      out.write("                                    <li> <a href=\"");
      out.print(request.getContextPath() );
      out.write("/ChangePassAdmin?submit=pass\">Change Password</a>\r\n");
      out.write("                                       \r\n");
      out.write("                                    </li>\r\n");
      out.write("\r\n");
      out.write("                                    <li><a href=\"");
      out.print(request.getContextPath() );
      out.write("/index.jsp\">LogOut</a>\r\n");
      out.write("                                        \r\n");
      out.write("                                            </li>\r\n");
      out.write("                                           \r\n");
      out.write("\r\n");
      out.write("                                       \r\n");
      out.write("                                </ul>\r\n");
      out.write("                            </div>\r\n");
      out.write("                        </div>\r\n");
      out.write("                    </div>\r\n");
      out.write("                </div>\r\n");
      out.write("            </div>\r\n");
      out.write("        </div>\r\n");
      out.write("    </header>\r\n");
      out.write("<!--End Header-->\r\n");
      out.write("\r\n");
      out.write("<!--start wrapper-->\r\n");
      out.write("<section class=\"wrapper\">\r\n");
      out.write("    <section class=\"page_head\">\r\n");
      out.write("        <div class=\"container\">\r\n");
      out.write("          \r\n");
      out.write("        </div>\r\n");
      out.write("    </section>\r\n");
      out.write("    <div class=\"container\">\r\n");
      out.write("    \r\n");
      out.write("    \r\n");
      out.write("    \r\n");
      out.write("    <!--  <div class=\"row sub_content\">\r\n");
      out.write("            \r\n");
      out.write("           <div class=\"col-lg-6 col-sm-6\" style=\"position:absolute; top: 300px;left: 300px;\">\r\n");
      out.write("           <div class=\"project_details\"> -->\r\n");
      out.write("\t\t\t\t\t\t\t<div class=\"widget_title\" style=\"position:absolute; top: 280px;left: 200px;\">\r\n");
      out.write("\t\t\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t\t</div>\r\n");
      out.write("\t\t <table id=\"myTable\" border=\"1\" style=\"border-collapse: collapse;\"  >\r\n");
      out.write("        <!--1st ROW-->\r\n");
      out.write("        <tr>\r\n");
      out.write("            <td ><img src=\"");
      out.print(request.getContextPath());
      out.write("/PasswordImages/Image1/Image1.jpg\"></td>\r\n");
      out.write("            <td><img src=\"");
      out.print(request.getContextPath());
      out.write("/PasswordImages/Image2/Image2.jpg\"></td>\r\n");
      out.write("            <td><img src=\"");
      out.print(request.getContextPath());
      out.write("/PasswordImages/Image3/Image3.jpg\"></td>\r\n");
      out.write("            <td><img src=\"");
      out.print(request.getContextPath());
      out.write("/PasswordImages/Image4/Image4.jpg\"></td>\r\n");
      out.write("           \r\n");
      out.write("        </tr>\r\n");
      out.write(" \r\n");
      out.write("        <!--2nd ROW-->\r\n");
      out.write("         <tr>\r\n");
      out.write("            <td ><img src=\"");
      out.print(request.getContextPath());
      out.write("/PasswordImages/Image5/Image5.jpg\"></td>\r\n");
      out.write("            <td><img src=\"");
      out.print(request.getContextPath());
      out.write("/PasswordImages/Image6/Image6.jpg\"></td>\r\n");
      out.write("            <td><img src=\"");
      out.print(request.getContextPath());
      out.write("/PasswordImages/Image7/Image7.jpg\"></td>\r\n");
      out.write("            <td><img src=\"");
      out.print(request.getContextPath());
      out.write("/PasswordImages/Image8/Image8.jpg\"></td>\r\n");
      out.write("           \r\n");
      out.write("        </tr>\r\n");
      out.write(" \r\n");
      out.write(" \r\n");
      out.write("       \r\n");
      out.write("    </table>\r\n");
      out.write("                            </div>\r\n");
      out.write("                           <div id=\"pageNavPosition\" style=\"position:absolute; top: 520px;left: 200px;\"></div>  \r\n");
      out.write("<br />  \r\n");
      out.write("<script type=\"text/javascript\"><!--  \r\n");
      out.write("        var pager = new Pager('keywords', 3); \r\n");
      out.write("      ");
      out.write("\r\n");
      out.write("        pager.init();   \r\n");
      out.write("        pager.showPageNav('pager', 'pageNavPosition');   \r\n");
      out.write("        pager.showPage(1);  \r\n");
      out.write("    //--></script>\r\n");
      out.write("\t\t\t\t\t\t<!-- </div>\r\n");
      out.write("           \r\n");
      out.write("           </div> \r\n");
      out.write("           \r\n");
      out.write("            \r\n");
      out.write("             \r\n");
      out.write("            </div>\r\n");
      out.write("            \r\n");
      out.write("            \r\n");
      out.write("        \r\n");
      out.write("            </div> -->\r\n");
      out.write("            </section>\r\n");
      out.write("  \r\n");
      out.write("<script type=\"text/javascript\" src=\"js/jquery-1.10.2.min.js\"></script>\r\n");
      out.write("<script src=\"js/bootstrap.min.js\"></script>\r\n");
      out.write("<script src=\"js/jquery.easing.1.3.js\"></script>\r\n");
      out.write("<script src=\"js/retina-1.1.0.min.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/jquery.cookie.js\"></script> <!-- jQuery cookie -->\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/styleswitch.js\"></script> <!-- Style Colors Switcher -->\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/jquery.smartmenus.min.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/jquery.smartmenus.bootstrap.min.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/owl.carousel.js\"></script><!-- Popover-JS -->\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/jflickrfeed.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/jquery.magnific-popup.min.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/jquery.isotope.min.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/swipe.js\"></script>\r\n");
      out.write("<script type=\"text/javascript\" src=\"js/jquery-scrolltofixed-min.js\"></script>\r\n");
      out.write("\r\n");
      out.write("<script src=\"js/main.js\"></script>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("</body>\r\n");
      out.write("</html>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          try { out.clearBuffer(); } catch (java.io.IOException e) {}
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
